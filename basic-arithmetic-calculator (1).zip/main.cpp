/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main() {
    double num1, num2;
    char operation;
    double result;

    std::cout << "This is a basic arithmetic calculator!" << std::endl;
    std::cout << "Enter the first number: ";
    std::cin >> num1;
    std::cout << "Enter the second number: ";
    std::cin >> num2;
    std::cout << "Choose an operator (+, -, *, /): ";
    std::cin >> operation;

    switch(operation) {
        case '+':
            result = num1 + num2;
            std::cout << "The ans of " << num1 << " + " << num2 << " is " << result << std::endl;
            break;
        case '-':
            result = num1 - num2;
            std::cout << "The ans of " << num1 << " - " << num2 << " is " << result << std::endl;
            break;
        case '*':
            result = num1 * num2;
            std::cout << "The ans of " << num1 << " * " << num2 << " is " << result << std::endl;
            break;
        case '/':
            if (num2 != 0) {
                result = num1 / num2;
                std::cout << "The result of " << num1 << " / " << num2 << " is " << result << std::endl;
            } else {
                std::cout << "Error: Division by zero is not allowed i.e result is undefined in this case." << std::endl;
            }
            break;
        default:
            std::cout << "Invalid operation. Please choose among these operators i.e  +, -, *, or /." << std::endl;
    }

    return 0;
}
